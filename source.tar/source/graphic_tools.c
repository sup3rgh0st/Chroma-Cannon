//sup3rgh0st
//graphic_tools.c
//12/5/14


#include <3ds.h>
#include "graphic_tools.h"

void paint_pixel(u8* fb, u16 x, u16 y, u8 red, u8 green, u8 blue) {
	fb[3*(y+x*240)] = red;
	fb[3*(y+x*240)+1] = green;
	fb[3*(y+x*240)+2] = blue;
}

void paint_rect(u8* fb, u16 x1, u16 y1, u16 x2, u16 y2, u8 red, u8 green, u8 blue) {
	int i=0;
	int k=0;
	for(i = x1;i <= x2; i++){
		for(k = y1; k <= y2; k++){
			paint_pixel(fb,i,k,red,green,blue);
		}
	}
}