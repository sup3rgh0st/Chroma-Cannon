//sup3rgh0st

#ifndef COLOR_TOOLS_H
#define COLOR_TOOLS_H

struct Color {
	u8 red;
	u8 green;
	u8 blue;
	
	Color()=default;
	//Color(int r, int g, int b) : red(r), green(g), blue(b) {}
};

#endif