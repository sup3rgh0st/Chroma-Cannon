//sup3rgh0st

#ifndef GRAPHIC_TOOLS_H
#define GRAPHIC_TOOLS_H

void paint_pixel(u8* fb, u16 x, u16 y, u8 red, u8 green, u8 blue);


#endif