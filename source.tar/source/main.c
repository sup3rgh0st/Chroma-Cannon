//sup3rgh0st

#include <3ds.h>
#include "color_tools.h"
#include "graphic_tools.h"

int main()
{
	// Initialize services
	srvInit();
	aptInit();
	hidInit(NULL);
	gfxInit();
	//gfxSet3D(true); // uncomment if using stereoscopic 3D
	
	// Main loop
	while (aptMainLoop())
	{
		gspWaitForVBlank();
		hidScanInput();

		// Your code goes here
		
		u32 kDown = hidKeysDown();
		u32 kHeld = hidKeysHeld();
		
		//Exit Program
		if (kDown & KEY_START)
			break; // break in order to return to hbmenu
			
		
		// Example rendering code that displays a white pixel
		// Please note that the 3DS screens are sideways (thus 240x400 and 240x320)
		u8* fbTop = gfxGetFramebuffer(GFX_TOP, GFX_LEFT, NULL, NULL);
		memset(fbTop, 0, 240*400*3);
		
		
		

		// Flush and swap framebuffers
		gfxFlushBuffers();
		gfxSwapBuffers();
	}

	// Exit services
	gfxExit();
	hidExit();
	aptExit();
	srvExit();
	return 0;
}
