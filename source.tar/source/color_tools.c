//sup3rgh0st
//color_tools.c

#include <3ds.h>
#include "color_tools.h"


